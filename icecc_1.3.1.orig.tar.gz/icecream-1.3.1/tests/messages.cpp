#include "messages.h"

void f()
    {
    int unused; // this should give a warning about being unused
    }
