// #include "includes.h" - will be done using -include includes.h
#include <stdio.h>

void f()
    {
    std::cout << std::endl; // use something included only by includes.h
    }
