#include "make.h"

void make1()
    {
    }

int main()
    {
    return 0;
    }
