#define FOO bar
#define NUMBER 10
int f()
    {
    return NUMBER;
    }
