int f()
{
    return 123;
}
