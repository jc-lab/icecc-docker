bool foo()
    {
    return false;
    }
